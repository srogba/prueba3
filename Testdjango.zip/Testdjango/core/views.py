from django.shortcuts import render
from .models import Producto
# Create your views here.

def home(request):
    productos = Producto.objects.all()
    data = {
        'productos': productos
    }
    return render(request, 'core/home.html', data)

def contacto(request):
    return render(request, 'core/contacto.html')

def galeria(request):
    return render(request, 'core/galeria.html')
